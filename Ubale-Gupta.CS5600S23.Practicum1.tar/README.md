# Instructions to run this program

0. Navigate to this directory.
1. run "make" to prepare files.
2. run "./pm_heap_run" in the same directory to run the program.
